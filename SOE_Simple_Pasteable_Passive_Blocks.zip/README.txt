﻿SOE PASSIVE COLLECTION — SIMPLE PASTEABLE BLOCKS

How to use
==========
1. Open Windows PowerShell as the normal SOE user (NOT Administrator).
2. Open one of the numbered .txt files in this ZIP.
3. Copy the entire PowerShell block.
4. Paste it into PowerShell and press Enter.
5. The results file will be written directly to:

   C:\Users\<your-user>\XX-Name.txt

For example:
   C:\Users\sudom\01-Baseline.txt

Notes
=====
- No setup command is required.
- No $SOE variable is required.
- These are passive/read-only collection blocks.
- They do not create persistence, install software, run test payloads, or attempt bypasses.
- "Access Denied" or unavailable output may be useful evidence for the standard-user boundary.
- Run each cohort separately. If one command is restricted, the other cohort files can still be collected.

Recommended order
=================
01-Baseline
02-Policy-Accounts
03-Device-Security
04-Endpoint-Security
05-Installed-Software
06-Network
07-Windows-Update
08-Logging
09-Privilege-Escalation
10-Permissions
11-Persistence
12-Named-Pipes
